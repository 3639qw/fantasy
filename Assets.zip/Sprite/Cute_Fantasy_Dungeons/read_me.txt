Hello! Thank you for buying the Cute Fantasy Dungeons asset pack.
	
License:
   - You can use these assets in any commercial or non-commercial projects.
   - You can modify the assets.
   - You can not redistribute or resale, even if modified

If you like the asset pack leave a rating and comment. It helps to support the asset pack and get more people to see it. Thanks!